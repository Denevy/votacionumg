<?php

// src/Tutorial/BlogBundle/Controller/CommentAdminController.php

namespace Umg\VotacionBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as Controller;

class UsuarioAdminController extends Controller
{

}
