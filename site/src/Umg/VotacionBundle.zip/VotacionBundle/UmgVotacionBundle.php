<?php

namespace Umg\VotacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UmgVotacionBundle extends Bundle
{
}
